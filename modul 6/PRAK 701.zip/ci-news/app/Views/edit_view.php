<div class="container p-5">
    <a href="<?= base_url('Buku');?>" class="btn btn-secondary mb-2">Kembali</a>
    <div class="card">
        <div class="card-header bg-info text-white">
            <h4 class="card-title">Edit Buku : <?= $buku->judul;?></h4>
        </div>
        <div class="card-body">
            <form method="post" action="<?= base_url('Buku/update');?>">
                <div class="form-group">
                    <label for="">Judul</label>
                    <input type="text" value="<?= $buku->judul;?>" name="judul" required class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Penulis</label>
                    <input type="text" value="<?= $buku->penulis;?>" name="penulis" required class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Penerbit</label>
                    <input type="text" value="<?= $buku->penerbit;?>" name="penerbit" required class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Tahun Terbit</label>
                    <input type="number" value="<?= $buku->tahun_terbit;?>" name="tgl" required class="form-control">
                </div>
                <input type="hidden" value="<?= $buku->id;?>" name="id">
                <button class="btn btn-success">Edit Data</button>
            </form>
            
        </div>
    </div>
</div>