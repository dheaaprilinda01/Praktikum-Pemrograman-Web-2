<?php namespace App\Controllers;

class Page extends BaseController
{
	public function signin()
	{
		echo view("signin");
	}
    
    public function signup()
	{
		echo view("signup");
	}
    
    public function postindex()
	{
		echo view("postindex");
	}

}