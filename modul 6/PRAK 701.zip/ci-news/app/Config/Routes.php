<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/signin', 'page::signin');
$routes->get('/signup', 'Page::signup');
$routes->get('/Buku', 'Buku::index');
// Halaman Tambah
$routes->get('Buku/tambah', 'Buku::tambah');
// Halaman Edit
$routes->get('Buku/edit/(:any)', 'Buku::edit/$1');
// Proses CRUD
// Insert
$routes->post('Buku/add', 'Buku::add');
// Update
$routes->post('Buku/update', 'Buku::update');
// Hapus
$routes->get('Buku/hapus/(:any)', 'Buku::hapus/$1');
$routes->get('/auth/register', 'Auth::register');
$routes->post('/auth/registerPost', 'Auth::registerPost');
$routes->get('/auth/login', 'Auth::login');
$routes->post('/auth/loginPost', 'Auth::loginPost');
$routes->get('/auth/logout', 'Auth::logout');

